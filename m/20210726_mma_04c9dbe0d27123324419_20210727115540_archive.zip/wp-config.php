<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'qF+F$Ck_!Sp& *!0%zM$i5r52Z~<CY}pF9M<+jD~c4=|LS{_bO_-^`(rc4A|#:XP' );

define( 'SECURE_AUTH_KEY',  '>BmCP AN/e2t%+wwJM:5y[AmR L_MY{X6=2UP7FpF<l>HN6 $tYDuLrf#a-zH|Ge' );

define( 'LOGGED_IN_KEY',    '0|uot)^[sEOd4UcpQX0GwmC_q~-L}FRO/#DxKiTRNuuDwX5]an kupEMS>]n^aXB' );

define( 'NONCE_KEY',        'BF-)WB<U{&^kuV!+woj|_zR{O?a4I:}Tt4dSOEDtgg-h>Sz$W)qoNi9d}0Ypv0oh' );

define( 'AUTH_SALT',        'd=xbbCmX/R<&Yqu#<@/MCS9B@ZEs]t|^S6aN_>+ec@w6!BDLkuVlj0:$:I(G)E<6' );

define( 'SECURE_AUTH_SALT', '}gd70(hs_wA!A[X6YE >KL|9H4N:&,a-z{vt?gBOG4fp*e&-&xLeRnwXcB3ZE!^(' );

define( 'LOGGED_IN_SALT',   '|-7SY6)?zVIf6N)L:|yp#[+hJ_g}-zR@VF,g.vFr:[9G%sO;#GE2Rj7mV.J}Q*I/' );

define( 'NONCE_SALT',       'LczL1$`gA!T]3a=[o@i*`GTyiJJ[LtKDF@:[ak,j1tQ~%3R<2(:7ISFL~@vYyW9%' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

