<?php
/**
 * The template for displaying all single posts
 *
 * @link https://github.com/Fobiya/wp-template/
 *
 * @package fobiya
 */
 
get_header(); ?>

single.php
 

 
<?php

get_footer(); ?>